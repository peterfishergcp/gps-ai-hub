---
name: twin-meeting-notes
description: Ingests meeting transcripts, Gemini Meet Notes, Teams/Zoom summaries, or raw call notes into ~/antigravity-twin/memory/, strips embedded base64 bloat, applies 4-Tier Recency Compaction (0-7d, 8-30d, 31-90d, 90d+) to initiatives/<slug>/running_notes.md, extracts open commitments to gtd_board.md with Zero Task Decay, and updates Last_Touch_Date in contacts.md. Trigger on /twin-meeting-notes, "sync my meeting notes", "compact these call notes", or "extract action items from this transcript".
---

# Meeting Notes Harvester & 4-Tier Compactor (`/twin-meeting-notes`)

Turn messy meeting transcripts, shared call notes, or pasted summaries into structured, compacted Second Brain memory without bloating future context windows.

## Step 1 - Gather Transcript or Meeting Notes

1. **Pasted or Local File Input:** If the user pasted call notes or pointed to local `.md` / `.txt` / `.vtt` files, read them directly.
2. **Connected MCP Sources (Optional):** If `agy-ge-bridge` (`ge_search_records` / `ge_ask_instance`) or a Drive/SharePoint/Mail MCP is active and the user asks to pull recent meeting notes (such as *"Notes by Gemini"* or Teams meeting recaps), search **both** user-owned and shared-with-me documents from the requested window so organizer-owned transcripts are never missed.
3. Strip any inline `data:image/...;base64,...` blobs so vault Markdown files stay under `15 KB` of clean text (or run `node ~/.gemini/config/plugins/agy-second-brain/scripts/vault_cli.mjs ingest-notes --slug "<slug>" --title "<Title>" --file <path>` when `node` is on `PATH`).

## Step 2 - Update the 4-File Initiative Vault & Apply 4-Tier Compaction

Map each meeting to its matching folder under `~/antigravity-twin/memory/initiatives/<slug>/` (create a new 4-file folder if a new project or workstream appears). See `./references/compaction_rubric.md` for detailed examples:

1. **`initiatives/<slug>/running_notes.md` (4-Tier Recency Compaction):**
   - **Tier 1 (`0-7 Days` - Verbatim Summary, Key Quotes & Open Actions):** Prepend dated summary, key stakeholder objections/quotes, and concrete next steps.
   - **Tier 2 (`8-30 Days` - Tactical Summary):** Compact Tier 1 entries older than 7 days into 3-5 crisp bullets per session.
   - **Tier 3 (`31-90 Days` - Milestone Rollup):** Roll 31-90 day bullets into dated architectural, policy, or program milestones.
   - **Tier 4 (`90+ Days` - Evergreen Baseline):** Distill permanent historical background into one concise paragraph.
2. **`initiatives/<slug>/context_and_decisions.md` & `status.md`:**
   - Record any newly agreed technical specs, budget caps, deadlines, or `GREEN` / `AMBER` / `RED` status shifts.
3. **`gtd_board.md` (Zero Task Decay):**
   - Append every open commitment using `- [ ] [<slug>] <Verb + Deliverable> [Owner: <Name>] (Added: YYYY-MM-DD)`.
   - If the transcript confirms an existing `[ ]` item on `gtd_board.md` was completed, mark it `[x]`.
4. **`contacts.md`:**
   - Update `Last_Touch_Date` (`YYYY-MM-DD`) for every attendee on the call and clear any `STALE (>21d)` flag.

## Step 3 - Output Summary & Optional Follow-Up Draft

Return a short summary showing:
- Which vault files were created or updated (`running_notes.md`, `context_and_decisions.md`, `gtd_board.md`, `contacts.md`),
- Newly added `[ ]` commitments and any `[x]` items closed out,
- An offer to generate a `[Draft-Only]` post-meeting recap via **`/digital-twin`**.
